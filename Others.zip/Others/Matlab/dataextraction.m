clear all; clc; close all;

excelextract;

inx1 = find(logical(diff(Key1)));

lengths1 = zeros(length(inx1)+1,1);
lengths1(1) = inx1(1);
for i=1:length(inx1)-1
    lengths1(i+1) = inx1(i+1) - inx1(i);
end
lengths1(end) = length(Key1) - inx1(end);

maxSize1 = max(lengths1);
idx1 = find(lengths1 == maxSize1);

x1 = zeros(maxSize1,length(lengths1));
y1 = zeros(maxSize1,length(lengths1));
z1 = zeros(maxSize1,length(lengths1));

if find(idx1 == 1)
    x1(:,1) = Acc_X1(1:inx1(1));
    y1(:,1) = Acc_Y1(1:inx1(1));
    z1(:,1) = Acc_Z1(1:inx1(1));
else
    x1(:,1) = resample(Acc_X1(1:inx1(1)),maxSize1,inx1(1));
    y1(:,1) = resample(Acc_Y1(1:inx1(1)),maxSize1,inx1(1));
    z1(:,1) = resample(Acc_Z1(1:inx1(1)),maxSize1,inx1(1));
end

for i=2:length(lengths1)-1
    if find(idx1 == i)
        x1(:,i) = Acc_X1(inx1(i-1)+1:inx1(i));
        y1(:,i) = Acc_Y1(inx1(i-1)+1:inx1(i));
        z1(:,i) = Acc_Z1(inx1(i-1)+1:inx1(i));
    else
        x1(:,i) = resample(Acc_X1(inx1(i-1)+1:inx1(i)),maxSize1,lengths1(i));
        y1(:,i) = resample(Acc_Y1(inx1(i-1)+1:inx1(i)),maxSize1,lengths1(i));
        z1(:,i) = resample(Acc_Z1(inx1(i-1)+1:inx1(i)),maxSize1,lengths1(i));
    end
end

if find(idx1 == length(lengths1))
    x1(:,length(lengths1)) = Acc_X1(inx1(end)+1:end);
    y1(:,length(lengths1)) = Acc_Y1(inx1(end)+1:end);
    z1(:,length(lengths1)) = Acc_Z1(inx1(end)+1:end);
else
    x1(:,length(lengths1)) = resample(Acc_X1(inx1(end)+1:end),maxSize1,inx1(end)+1);
    y1(:,length(lengths1)) = resample(Acc_Y1(inx1(end)+1:end),maxSize1,inx1(end)+1);
    z1(:,length(lengths1)) = resample(Acc_Z1(inx1(end)+1:end),maxSize1,inx1(end)+1);
end

%% ICA
[~,signals] = size(x1);
for i=1:2:signals
    Zficax(i:i+1,:) = fastICA(x1(:,i:i+1)',2);
    Zficay(i:i+1,:) = fastICA(y1(:,i:i+1)',2);
    Zficaz(i:i+1,:) = fastICA(z1(:,i:i+1)',2);
end
%% FFT

Fs = 8;                 % Sampling frequency                    
T = 1/Fs;               % Sampling period       
L1 = maxSize1;          % Length of signal
t1 = (0:L1-1)*T;        % Time vector

X1 = fft(x1);
Y1 = fft(y1);
Z1 = fft(z1);

P21x = abs(X1/L1);
P21y = abs(Y1/L1);
P21z = abs(Z1/L1);

P11x = P21x(1:L1/2+1,:);
P11y = P21y(1:L1/2+1,:);
P11z = P21z(1:L1/2+1,:);

P11x(2:end-1) = 2*P11x(2:end-1);
P11y(2:end-1) = 2*P11y(2:end-1);
P11z(2:end-1) = 2*P11z(2:end-1);

f1 = Fs*(0:(L1/2))/L1;


%% Plot
figure;
subplot(3,1,1)
title('X coordinate')
hold on;
for i = 1:length(lengths1)
    plot(x1(:,i))
end
hold off;

%figure;
subplot(3,1,2)
title('Y coordinate')
hold on;
for i = 1:length(lengths1)
    plot(y1(:,i))
end
hold off;

%figure;
subplot(3,1,3)
title('Z coordinate')
hold on;
for i = 1:length(lengths1)
    plot(z1(:,i))
end
hold off;

figure;
subplot(3,1,1)
title('Single-Sided Amplitude Spectrum of X(f)')
plot(f1,P11x) 
xlabel('f (Hz)')
ylabel('|P1x(f)|')

%figure;
subplot(3,1,2)
title('Single-Sided Amplitude Spectrum of Y(f)')
plot(f1,P11y) 
xlabel('f (Hz)')
ylabel('|P1y(f)|')

%figure;
subplot(3,1,3)
title('Single-Sided Amplitude Spectrum of Z(t)')
plot(f1,P11z) 
xlabel('f (Hz)')
ylabel('|P1z(f)|')

%% ICA Analysis plot
figure;
subplot(3,1,1)
title('ICA Analysis - X component')
hold on;

[zficaxrows,~]=size(Zficax);
for i = 1:zficaxrows
    plot(t1,Zficax(i,:));
end
hold off;

subplot(3,1,2)
title('ICA Analysis - Y component')
hold on;

[zficayrows,~]=size(Zficay);
for i = 1:zficayrows
    plot(t1,Zficay(i,:));
end
hold off;

subplot(3,1,3)
title('ICA Analysis - Z component')
hold on;
[zficazrows,~]=size(Zficaz);
for i = 1:zficazrows
    plot(t1,Zficaz(i,:));
end
hold off;

