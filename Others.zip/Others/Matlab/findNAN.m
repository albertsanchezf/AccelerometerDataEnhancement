function [ Y ] = findNAN( x )

    [M,I] = find(isnan(x));
    X=x;

    for i=1:length(M)
        xl = x(M(i)-1);
        xr = x(M(i)+1);
        j=2;
        while isnan(xl) || isnan(xr)
            if isnan(xl)
                xl = x(M(i)-j);
            end
            if isnan(xr)
                xr= x(M(i)+j);
            end
            j=j+1;
        end
        X(M(i)) = (xl+xr)/2;
    end
    Y=X;
end


