%% Getting Data
clear all; close all; clc;
accx = xlsread('Book1.xlsx','Sheet1','A1:A21');
accy = xlsread('Book1.xlsx','Sheet1','B1:B21');
accz = xlsread('Book1.xlsx','Sheet1','C1:C21');
gyra = xlsread('Book1.xlsx','Sheet1','E1:E21');
gyrb = xlsread('Book1.xlsx','Sheet1','F1:F21');
gyrc = xlsread('Book1.xlsx','Sheet1','G1:G21');
t = xlsread('Book1.xlsx','Sheet1','D1:D21');

fs = 8;
L = length(t);

%% Adapting signals

% Matching lengths
if (L ~= length(accx))
    accx(length(accx):L) = accx(end);
end
if (L ~= length(accy))
    accy(length(accy):L) = accy(end);
end
if (L ~= length(accz))
    accz(length(accz):L) = accz(end);
end

% Unitary Amplitude
accx = 1/(max(accx)-min(accx))*accx;
accy = 1/(max(accy)-min(accy))*accy;
accz = 1/(max(accz)-min(accz))*accz;
gyra = 1/(max(gyra)-min(gyra))*gyra;
gyrb = 1/(max(gyrb)-min(gyrb))*gyrb;
gyrc = 1/(max(gyrc)-min(gyrc))*gyrc;


% Avoiding NaN
accx=findNAN(accx);
accy=findNAN(accy);
accz=findNAN(accz);
gyra=findNAN(gyra);
gyrb=findNAN(gyrb);
gyrc=findNAN(gyrc);

%% Plot data values

%Accelerometer
figure(1);
hold on;
plot(t,accx);
plot(t,accy);
plot(t,accz);
title('Temporal accelerometer values');
legend('x','y','z');
xlabel('t')
hold off;

%Gyroscope
figure(2);
hold on;
plot(t,gyra);
plot(t,gyrb);
plot(t,gyrc);
title('Temporal gyroscopic values');
legend('gyra','gyrb','gyrc');
xlabel('t');
hold off;

%% FFT
X = fft(accx);
Y = fft(accy);
Z = fft(accz);

f = fs*(1/L)*(0:L/2);

X2 = abs(X/L);
X1 = X2(1:L/2+1);
X1(2:end-1) = 2*X1(2:end-1);

Y2 = abs(Y/L);
Y1 = X2(1:L/2+1);
Y1(2:end-1) = 2*Y1(2:end-1);

Z2 = abs(Z/L);
Z1 = Z2(1:L/2+1);
Z1(2:end-1) = 2*Z1(2:end-1);

figure(3);
hold on;
plot(f,X1);
plot(f,Y1);
plot(f,Z1);
title('Single-Sided Amplitude Spectrum')
xlabel('f (Hz)')
ylabel('|P1(f)|')
hold off;