%% Demostarci? Autocorrelaci?(0) = Pot?ncia

% Rx(0) = Px = E(x^2)

clear all; clc; close all;

L = 50;
Fs = 1000;
Ts = 1/Fs;
ts = (0:L-1)*Ts;

x = sin(2*pi*ts*50);

figure(1);
plot(ts,x);

[c,lags] = xcorr(x,x);

figure(2);
stem(lags,c);

Rx0 = sum(x.^2)
