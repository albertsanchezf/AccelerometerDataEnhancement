% Demo on Wiener filter based on Wiener-Hopf equations
%   This demo shows how Wiener filtering works for recovering the reference signal
%   from a noisy measured signal
%
% M. Buzzoni
% May 2019

clear
close all
clc

fs = 4000; % sampling frequency
T = 1;% total recording time
L = T .* fs; % signal length
tt = (0:L-1)/fs; % time vector
ff = (0:L-1)*fs/L;

y = sin(2*pi*120 .* tt); y = y(:); % reference sinusoid
x = 0.50*randn(L,1) + y; x = x(:); % sinusoiud with additive Gaussian noise


N = 200; % filter order
[xest,b,MSE] = wienerFilt(x,y,N);

% plot results
figure
subplot(311)
plot(tt,x,'k'), hold on, plot(tt,y,'r')
title('Wiener filtering example')
legend('noisy signal','reference')
subplot(312)
plot(tt(N+1:end),xest,'k')
legend('estimated signal')
subplot(313)
plot(tt(N+1:end),(x(N+1:end) - xest),'k')
legend('residue signal')
xlabel('time (s)')
