clear all; clc; close all;
%%
cd('/Users/AlbertSanchez/Dropbox/TFM/Tests/ICA');
load RealData.mat;
load provaTJ.mat;

Incident_Type = 1; % From 1 to 8
nSignals = 1; % Number of signals that what to be used

% Find indexes and lengths for the different signals
inx = find(logical(diff(Key{Incident_Type}))); 
lengths = zeros(length(inx)+1,1);
lengths(1) = inx(1);
for i=1:length(inx)-1
    lengths(i+1) = inx(i+1) - inx(i);
end
lengths(end) = length(Key{Incident_Type}) - inx(end);

[x,y,z] = resampleSignals(inx,lengths,Acc_X,Acc_Y,Acc_Z,Incident_Type,nSignals);

%plotResampledSignals(x,y,z);

cd('/Users/AlbertSanchez/Dropbox/TFM/Tests/WienerFilter/wienerFilt');

[xLength,xSignals] = size(x);
[yLength,ySignals] = size(y);
[zLength,zSignals] = size(z);

if length(xJ) < xLength
    n = xLength/length(xJ);
    xJ = repmat(xJ,ceil(n));
end

if length(xJ) > xLength
    xJ = xJ(1:xLength);
end

N=50;
[xest,b,MSE] = wienerFilt(x,xJ,N);

% plot results
figure
subplot(311)
plot(x,'k')%, hold on, plot(y,'r')
title('Wiener filtering example')
%legend('noisy signal','reference')
subplot(312)
plot(xest,'k')
legend('estimated signal')
subplot(313)
plot((x(N+1:end) - xest),'k')
legend('residue signal')
xlabel('time (s)')
