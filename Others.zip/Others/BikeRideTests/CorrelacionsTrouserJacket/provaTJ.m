clear all; clc; %close all;
load provaTJ;

[cx,lagsx] = xcorr(xJ,xJ);
% [cy,lagsy] = xcorr(yJ,yT);
% [cz,lagsz] = xcorr(zJ,zT);

figure;

%subplot(2,3,1)
stem(lagsx,cx)
%%
subplot(2,3,2)
stem(lagsy,cy)
subplot(2,3,3)
stem(lagsz,cz)

tmp = corrcoef(xJ,xT);
xCoef = tmp(1,2);
tmp = corrcoef(yJ,yT);
yCoef = tmp(1,2);
tmp = corrcoef(zJ,zT);
zCoef = tmp(1,2);

coef = [xCoef,yCoef,zCoef]

%Shift to maximise correlation

[~,posX] = max(abs(cx));
[~,posY] = max(abs(cy));
[~,posZ] = max(abs(cz));

posX = posX - (length(lagsx)+1)/2;
posY = posY - (length(lagsy)+1)/2;
posZ = posZ - (length(lagsz)+1)/2;

xTs = circshift(xT,posX);
yTs = circshift(yT,posY);
zTs = circshift(zT,posZ);

[cxs,lagsxs] = xcorr(xJ,xTs);
[cys,lagsys] = xcorr(yJ,yTs);
[czs,lagszs] = xcorr(zJ,zTs);

subplot(2,3,4)
stem(lagsxs,cxs)
subplot(2,3,5)
stem(lagsys,cys)
subplot(2,3,6)
stem(lagszs,czs)

tmp = corrcoef(xJ,xTs);
xCoefS = tmp(1,2);
tmp = corrcoef(yJ,yTs);
yCoefS = tmp(1,2);
tmp = corrcoef(zJ,zTs);
zCoefS = tmp(1,2);

coefS = [xCoefS,yCoefS,zCoefS]



