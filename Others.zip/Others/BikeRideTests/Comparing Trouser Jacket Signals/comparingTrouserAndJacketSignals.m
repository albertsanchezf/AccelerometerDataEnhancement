clear all; clc; close all;

load('TrouserJacketSignals.mat');

% Plot Raw Signals
figure;
% X axis
subplot(3,1,1);
hold on;
plot(ts,xJ);
plot(ts,xT);
legend('Jacket','Trousers')
ylabel('X axis');

% Y axis
subplot(3,1,2);
hold on;
plot(ts,yJ);
plot(ts,yT);
legend('Jacket','Trousers')
ylabel('Y axis');

% Z axis
subplot(3,1,3);
hold on;
plot(ts,zJ);
plot(ts,zT);
legend('Jacket','Trousers')
ylabel('Z axis');

%% FFT

% Jacket Signals
XJ = fft(xJ);
YJ = fft(yJ);
ZJ = fft(zJ);

P21xJ = abs(XJ/L);
P21yJ = abs(YJ/L);
P21zJ = abs(ZJ/L);

P11xJ = P21xJ(1:L/2+1,:);
P11yJ = P21yJ(1:L/2+1,:);
P11zJ = P21zJ(1:L/2+1,:);

P11xJ(2:end-1) = 2*P11xJ(2:end-1);
P11yJ(2:end-1) = 2*P11yJ(2:end-1);
P11zJ(2:end-1) = 2*P11zJ(2:end-1);

% Trouser Signals
XT = fft(xT);
YT = fft(yT);
ZT = fft(zT);

P21xT = abs(XT/L);
P21yT = abs(YT/L);
P21zT = abs(ZT/L);

P11xT = P21xT(1:L/2+1,:);
P11yT = P21yT(1:L/2+1,:);
P11zT = P21zT(1:L/2+1,:);

P11xT(2:end-1) = 2*P11xT(2:end-1);
P11yT(2:end-1) = 2*P11yT(2:end-1);
P11zT(2:end-1) = 2*P11zT(2:end-1);

f = Fs*(0:(L/2))/L;

% Plot FFT Data
figure;
suptitle('Bike Ride - FFT')
subplot(3,1,1);
hold on;
plot(f,P11xJ); plot(f,P11xT);
legend('Jacket','Trouser');
hold off;
xlabel('f (Hz)'); ylabel('|P1X(f)|')

subplot(3,1,2);
hold on;
plot(f,P11yJ); plot(f,P11yT);
legend('Jacket','Trouser');
hold off;
xlabel('f (Hz)'); ylabel('|P1Y(f)|');

subplot(3,1,3);
hold on;
plot(f,P11zJ); plot(f,P11zT);
legend('Jacket','Trouser');
hold off;
xlabel('f (Hz)'); ylabel('|P1Z(f)|');

%% LPF
fc = 0.1;

lp = designfilt('lowpassfir','FilterOrder',20,'CutoffFrequency',fc, ...
       'DesignMethod','window','Window',{@kaiser,3},'SampleRate',Fs);

fvtool(lp,1,'Fs',Fs)

% Jacket signal
xJLP = filter(lp,xJ);
yJLP = filter(lp,yJ);
zJLP = filter(lp,zJ);

% Trouser signal
xTLP = filter(lp,xT);
yTLP = filter(lp,yT);
zTLP = filter(lp,zT);

% Plot Filtered Data
figure;
suptitle('Bike Ride - LPF (0-0.1 Hz)')

% X Axis
subplot(3,1,1);
hold on;
plot(ts,xJLP); plot(ts,xTLP);
legend('Jacket','Trousers');
hold off;
ylabel('x'); xlabel('t(s)');

% Y Axis
subplot(3,1,2);
hold on;
plot(ts,yJLP); plot(ts,yTLP);
legend('Jacket','Trousers');
hold off;
ylabel('y');xlabel('t(s)');

% Z Axis
subplot(3,1,3);
hold on;
plot(ts,zJLP); plot(ts,zTLP);
legend('Jacket','Trousers');
hold off;
ylabel('z');xlabel('t(s)');

%% FFT Post Filtering

% Jacket Signals
XJLP = fft(xJLP);
YJLP = fft(yJLP);
ZJLP = fft(zJLP);

P21xJLP = abs(XJLP/L);
P21yJLP = abs(YJLP/L);
P21zJLP = abs(ZJLP/L);

P11xJLP = P21xJLP(1:L/2+1,:);
P11yJLP = P21yJLP(1:L/2+1,:);
P11zJLP = P21zJLP(1:L/2+1,:);

P11xJLP(2:end-1) = 2*P11xJLP(2:end-1);
P11yJLP(2:end-1) = 2*P11yJLP(2:end-1);
P11zJLP(2:end-1) = 2*P11zJLP(2:end-1);

% Trouser Signals
XTLP = fft(xTLP);
YTLP = fft(yTLP);
ZTLP = fft(zTLP);

P21xTLP = abs(XTLP/L);
P21yTLP = abs(YTLP/L);
P21zTLP = abs(ZTLP/L);

P11xTLP = P21xTLP(1:L/2+1,:);
P11yTLP = P21yTLP(1:L/2+1,:);
P11zTLP = P21zTLP(1:L/2+1,:);

P11xTLP(2:end-1) = 2*P11xTLP(2:end-1);
P11yTLP(2:end-1) = 2*P11yTLP(2:end-1);
P11zTLP(2:end-1) = 2*P11zTLP(2:end-1);

f = Fs*(0:(L/2))/L;

% Plot FFT Data
figure;
suptitle('Bike Ride filtered - FFT')
subplot(3,1,1);
hold on;
plot(f,P11xJLP); plot(f,P11xTLP);
legend('Jacket','Trouser');
hold off;
xlabel('f (Hz)'); ylabel('|P1X(f)|')

subplot(3,1,2);
hold on;
plot(f,P11yJLP); plot(f,P11yTLP);
legend('Jacket','Trouser');
hold off;
xlabel('f (Hz)'); ylabel('|P1Y(f)|');

subplot(3,1,3);
hold on;
plot(f,P11zJLP); plot(f,P11zTLP);
legend('Jacket','Trouser');
hold off;
xlabel('f (Hz)'); ylabel('|P1Z(f)|');
