function [svm] = svmAcc(x,y,z)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
    svm = sqrt(x.^2+y.^2+z.^2);

end

