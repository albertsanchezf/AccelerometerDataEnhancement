clear all; clc; close all;

load NoUserTaggedData.mat;

% Incident_Type = 1; % From 1 to 8
% nSignals = 2; % Number of signals that what to be used

types       = zeros(1,8);
allMeans    = cell(2,3);
allVar      = cell(2,3);
allStd      = cell(2,3);
allMedian   = cell(2,3);
allMax      = cell(2,3);
allMin      = cell(2,3);
sma         = cell(2,1);
svmMeans    = cell(2,1);
svmVar      = cell(2,1);
svmStd      = cell(2,1);
X = cell(1,8);
Y = cell(1,8);
Z = cell(1,8);

Pxx = cell(1,8);
Pyy = cell(1,8);
Pzz = cell(1,8); 

f1 = cell(1,8);
Fs = cell(1,8);

c = [;;];
colors = {[0,0,0],[1,0,0],[0,1,0],[0,0,1],...
          [1,1,0],[1,0,1],[0,1,1],[0.5,0.5,0.5]};
cmap = [0,0,0;1,0,0;0,1,0;...
        0,0,1;1,1,0;1,0,1;...
        0,1,1;0.5,0.5,0.5];

for Incident_Type=1:8
    
    % Find indexes and lengths for the different signals
    inx = find(logical(diff(Key{Incident_Type}))); 
    lengths = zeros(length(inx)+1,1);
    lengths(1) = inx(1);
    for i=1:length(inx)-1
        lengths(i+1) = inx(i+1) - inx(i);
    end
    lengths(end) = length(Key{Incident_Type}) - inx(end);

    [x,y,z] = resampleSignals(inx,lengths,Acc_X,Acc_Y,Acc_Z,Incident_Type);
    %plotResampledSignals(x,y,z);
    
    [lSignals,nSignals] = size(x);
    Fs{Incident_Type} = lSignals/6; % Samples are taken for 6 seconds
        
    % FFT
    X{Incident_Type} = fft(x);
    Y{Incident_Type} = fft(y);
    Z{Incident_Type} = fft(z);
    f1{Incident_Type} = Fs{Incident_Type}*(0:(lSignals/2))/lSignals;
    
    % Power Spectral Density
    Pxx{Incident_Type} = X{Incident_Type}.^2/lSignals;
    Pyy{Incident_Type} = Y{Incident_Type}.^2/lSignals;
    Pzz{Incident_Type} = Z{Incident_Type}.^2/lSignals;	
    
    c = [c; repmat(colors{Incident_Type},nSignals,1)];

    types(Incident_Type) = nSignals;
    
end

for i=1:8
    figure;
    suptitle(strcat('Power Spectral Density: Type',' ',int2str(i)));
    subplot(311);
    hold on
        for j=1:types(i)
            plot(f1{i},Pxx{i}(1:length(f1{i}),j));
            xlim([0 2])
        end
    hold off;
    
    subplot(312);
    hold on
        for j=1:types(i)
            plot(f1{i},Pyy{i}(1:length(f1{i}),j));
            xlim([0 2])
        end
    hold off;

    subplot(313);
    hold on
        for j=1:types(i)
            plot(f1{i},Pxx{i}(1:length(f1{i}),j));
            xlim([0 2])
        end
    hold off;
end
    
  