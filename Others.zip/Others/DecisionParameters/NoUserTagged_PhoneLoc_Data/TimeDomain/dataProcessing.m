clear all; clc; close all;

load NoUserTagged_PhoneLoc_Data.mat;

% Incident_Type = 1; % From 1 to 8
% nSignals = 2; % Number of signals that what to be used
% pLocType = 

for pLocType=0:0

    typeNSignalsAcc = zeros(1,8);

    allMeans    = cell(2,3);
    allVar      = cell(2,3);
    allStd      = cell(2,3);
    allMedian   = cell(2,3);
    allMax      = cell(2,3);
    allMin      = cell(2,3);
    sma         = cell(2,1);
    svmMeans    = cell(2,1);
    svmVar      = cell(2,1);
    svmStd      = cell(2,1);

    cAcc = [;;];
    colors = {[0,0,0],[1,0,0],[0,1,0],[0,0,1],...
              [1,1,0],[1,0,1],[0,1,1],[0.5,0.5,0.5]};
    cmap = [0,0,0;1,0,0;0,1,0;...
            0,0,1;1,1,0;1,0,1;...
            0,1,1;0.5,0.5,0.5];

    for Incident_Type=1:8
        
        % Find indexes and lengths for the different signals
        inx = find(logical(diff(Key{Incident_Type}))); 
        lengths = zeros(length(inx)+1,1);
        lengths(1) = inx(1);
        for i=1:length(inx)-1
            lengths(i+1) = inx(i+1) - inx(i);
        end
        lengths(end) = length(Key{Incident_Type}) - inx(end);



        [x_acc,y_acc,z_acc] = resampleSignals(inx,lengths,Acc_X,Acc_Y,Acc_Z,Incident_Type);
        %plotResampledSignals(x_acc,y_acc,z_acc);
        
        [~,nSignalsAcc] = size(x_acc);

        phoneLoc = zeros(1,nSignalsAcc);
        phoneLoc(1) = pLoc{Incident_Type}(1);
        for i=2:nSignalsAcc-1
            phoneLoc(i) = pLoc{Incident_Type}(inx(i));
        end        

        deleteColumns = find(phoneLoc ~= pLocType);

        x_acc(:,deleteColumns) = [];
        y_acc(:,deleteColumns) = [];
        z_acc(:,deleteColumns) = []; 

        [~,nSignalsAccType] = size(x_acc);
        
        cAcc = [cAcc; repmat(colors{Incident_Type},nSignalsAccType,1)];

        typeNSignalsAcc(Incident_Type) = nSignalsAccType;
        [allMeans,allVar,allStd,allMedian,allMax,allMin,sma,svm,svmMeans,...
            svmVar,svmStd] = calculateStatistics(allMeans,allVar,allStd,...
            allMedian,allMax,allMin,sma,svmMeans,svmVar,svmStd,x_acc,y_acc,z_acc);
        
    end

    nTotalSignalsAcc = sum(typeNSignalsAcc);

    % Plot X Axis: MEAN, VAR, STD
    plot3fx_withColormap('Mean Value',allMeans{1,1},allMeans{2,1},...
                         'Variance Value',allVar{1,1},allVar{2,1},...
                         'Standard Deviation Value',allStd{1,1},allStd{2,1},...
                         'Accelerometer X Axis',nTotalSignalsAcc,cAcc,cmap,typeNSignalsAcc);

    % Plot X Axis: MEDIAN, MAX, MIN
    plot3fx_withColormap('Median Value',allMedian{1,1},allMedian{2,1},...
                         'Max Value',allMax{1,1},allMax{2,1},...
                         'Min Value',allMin{1,1},allMin{2,1},...
                         'Accelerometer X Axis',nTotalSignalsAcc,cAcc,cmap,typeNSignalsAcc);

    % Plot Y Axis: MEAN, VAR, STD
    plot3fx_withColormap('Mean Value',allMeans{1,2},allMeans{2,2},...
                         'Variance Value',allVar{1,2},allVar{2,2},...
                         'Standard Deviation Value',allStd{1,2},allStd{2,2},...
                         'Accelerometer Y Axis',nTotalSignalsAcc,cAcc,cmap,typeNSignalsAcc);

    % Plot Y Axis: MEDIAN, MAX, MIN
    plot3fx_withColormap('Median Value',allMedian{1,2},allMedian{2,2},...
                         'Max Value',allMax{1,2},allMax{2,2},...
                         'Min Value',allMin{1,2},allMin{2,2},...
                         'Accelerometer Y Axis',nTotalSignalsAcc,cAcc,cmap,typeNSignalsAcc);

    % Plot Z Axis: MEAN, VAR, STD
    plot3fx_withColormap('Mean Value',allMeans{1,3},allMeans{2,3},...
                         'Variance Value',allVar{1,3},allVar{2,3},...
                         'Standard Deviation Value',allStd{1,3},allStd{2,3},...
                         'Accelerometer Z Axis',nTotalSignalsAcc,cAcc,cmap,typeNSignalsAcc);

    % Plot Z Axis: MEDIAN, MAX, MIN
    plot3fx_withColormap('Median Value',allMedian{1,3},allMedian{2,3},...
                         'Max Value',allMax{1,3},allMax{2,3},...
                         'Min Value',allMin{1,3},allMin{2,3},...
                         'Accelerometer Z Axis',nTotalSignalsAcc,cAcc,cmap,typeNSignalsAcc);

    % Plot SMA
    figure;
    scatter(1:nTotalSignalsAcc,sma{1},25,cAcc);
    if sma{2} ~= 0
        offset = 1;
        for i=1:length(typeNSignalsAcc)
            x1 = offset;
            x2 = offset + typeNSignalsAcc(i) - 1;
            line([x1,x2],[sma{2}(i),sma{2}(i)]);
            offset = x2 + 1;
        end
    end
    title('SMA')

    colormap(cmap);
    chb = colorbar();
    set(chb,'Ticks',0.125/2:0.125:1,'TickLabels',...
        {'Typ.1','Typ.2','Typ.3','Typ.4','Typ.5','Typ.6','Typ.7','Typ.8'});

    % Plot SVM: MEAN, VAR, STD
    plot3fx_withColormap('Mean Value',svmMeans{1},svmMeans{2},...
                         'Variance Value',svmVar{1},svmVar{2},...
                         'Starndard Deviation Value',svmStd{1},svmStd{2},...
                         'SVM Statistics',nTotalSignalsAcc,cAcc,cmap,typeNSignalsAcc);

end