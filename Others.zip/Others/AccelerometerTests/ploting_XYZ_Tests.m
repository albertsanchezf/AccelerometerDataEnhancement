
load('/Users/AlbertSanchez/Desktop/TFM (noDropBox)/AccelerometerTests/XAxis/acc_x_axis');
%%
load('/Users/AlbertSanchez/Desktop/TFM (noDropBox)/AccelerometerTests/YAxis/acc_y_axis','y');
%%
load('/Users/AlbertSanchez/Desktop/TFM (noDropBox)/AccelerometerTests/ZAxis/acc_z_axis','z');

%%
lmin = min([length(x),length(y),length(z)]);

x=x(1:lmin);
y=y(1:lmin);
z=z(1:lmin);

%%
figure;
suptitle('Accelerometer tests - RAW Data')
subplot(3,1,1)
plot(ts,x)
ylabel('x(m/s^2)');xlabel('t(s)');
subplot(3,1,2)
plot(ts,y)
ylabel('y(m/s^2)');xlabel('t(s)');
subplot(3,1,3)
plot(ts,z)
ylabel('z(m/s^2)');xlabel('t(s)');