Fs = 100;                       % Sampling Frequency (Hz)
Fn = Fs/2;                      % Nyquist Frequency (Hz)
passband = [5.0 20]/Fn;         % Passband (Hz)
stopband = [0.1 40]/Fn;         % Stopband (Hz)
passripple =  1;                % Passband Ripple (dB)
stopripple = 10;                % Stopband Ripple (dB)
[n,Wn]  = buttord(passband, stopband, passripple, stopripple);
[z,p,k] = butter(n,Wn);
[sos,g] = zp2sos(z,p,k);
figure(1)
freqz(sos,[0:0.1:50], Fs)